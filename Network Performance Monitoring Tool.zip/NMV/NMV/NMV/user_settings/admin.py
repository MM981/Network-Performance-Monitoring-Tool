from django.contrib import admin
from .models import AlertSettings


# Register your models here.
admin.site.register(AlertSettings)